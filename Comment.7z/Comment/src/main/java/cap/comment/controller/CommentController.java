package cap.comment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



import cap.comment.model.Comments;
import cap.comment.model.Status;
import cap.comment.service.ICommentService;
import cap.comment.service.IStatusService;




@RestController
public class CommentController {

	@Autowired
	private IStatusService statusService;
	
	@Autowired
	private  ICommentService CommentService;
	@PostMapping("/comments")
	private ResponseEntity<List<Comments>> saveComment(@RequestBody Comments comment){
		//System.out.println("Controller");
		List<Comments> comments=CommentService.saveComment(comment);
		if(comments.isEmpty()) {
			return new ResponseEntity("Sorry ...",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Comments>>(comments,HttpStatus.OK);
	}
	
	@GetMapping("/comments")
	private ResponseEntity<List<Comments>> getProducts(){
		List<Comments> comments=CommentService.getAllComments();
		if(comments.isEmpty()) {
			return new ResponseEntity("No product available",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Comments>>(comments,HttpStatus.OK);
	}
	
	@PostMapping("/status")
	public String  saveStatus(@RequestBody Status status){
		
		boolean status1 = statusService.saveStatus(status);
		if(status1 == false) 
			return "failed";
		return "success";	
		}
	
	
	@GetMapping("/status")
	public ResponseEntity<List<Status>>getAllStatus(){

		List<Status> products=statusService.getAllStatus();
		
		
		if(products.isEmpty())
			return new ResponseEntity("Sorry! Product not available",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Status>>(products, HttpStatus.OK);

	}

	

} 
	
	

