package cap.comment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import cap.comment.dao.ICommentDao;
import cap.comment.model.Comments;

@Service("CommentService")
public class CommentService implements ICommentService{

	
	@Autowired
	private ICommentDao commentdao;
	@Override
	public List<Comments> saveComment(Comments comment) {
		Comments pro=commentdao.save(comment);
		System.out.println(pro);
		return commentdao.findAll();
		
	}
	@Override
	public List<Comments> getAllComments() {
		return commentdao.findAll();
	}

}
