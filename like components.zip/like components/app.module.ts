import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LikeCommentComponent } from './like-comment/like-comment.component';
import { HttpClientModule } from '@angular/common/http';
import { LikeCommentService } from './like-comment.service';
import { FormsModule } from '@angular/forms';
import { ChatComponent } from './chat/chat.component';
@NgModule({
  declarations: [
    AppComponent,
    LikeCommentComponent,
    ChatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule     
  ],
  providers: [LikeCommentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
