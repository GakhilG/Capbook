import { Component, OnInit } from '@angular/core';
import { LikeCommentService } from '../like-comment.service';
import { Status } from './status';
import { attachEmbeddedView } from '@angular/core/src/view';
import { Likes } from './comment';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-like-comment',
  templateUrl: './like-comment.component.html',
  styleUrls: ['./like-comment.component.css']
})
export class LikeCommentComponent implements OnInit {

  displayTextbox:boolean=false;
  displayComments:Comment[];
  comments:Comment=new Comment;
  status:Status=new Status;
  like:Likes=new Likes;
  likeCount:number;
  constructor(private likecommentservice:LikeCommentService) { }

  private r:ActivatedRoute;
  ngOnInit() {
    
  
  }

  displayTextArea(){
    this.displayTextbox=true;
  }

  getComments(status_id:number){
    this.likecommentservice.getComments(status_id).subscribe(data=>{
      this.displayComments=data;

    });
  };
  addComments(status_id:number){
    this.likecommentservice.addComments(status_id,this.comments).subscribe(data=>{
      
    });
  };

  updateLikeCount(status_id:number){
    this.likecommentservice.updateLikeCount(status_id,this.like).subscribe(data=>{});
  };
  updateDislikeCount(status_id:number){
    this.likecommentservice.updateDislikeCount(status_id,this.like).subscribe(data=>{});
  };
  getLikeCount(status_id:number){
    this.likecommentservice.getLikeCount(status_id).subscribe(data=>{
      this.likeCount=data;
    });
  };
}
