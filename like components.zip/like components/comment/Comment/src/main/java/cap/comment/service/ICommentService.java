package cap.comment.service;

import java.util.List;

import cap.comment.model.Comments;

public interface ICommentService {

	List<Comments> saveComment(Comments comment);

	List<Comments> getAllComments();

	List<Comments> getAllCommentsByStatusId(Integer status_id);

	List<Comments> saveCommentByStatusId(Integer status_id, Comments comment);

}
