package com.capg.chat.service;

import java.util.List;

import com.capg.chat.model.Chat;

public interface IChatService {

	List<Chat> saveChat(Chat chat);

	List<Chat> getAllChats();

}
