package com.capg.chat.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.chat.model.Message;

@Repository("msgDao")
public interface IMsgDao extends JpaRepository<Message, Long>{

}
