package com.capg.chat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.chat.dao.IChatDao;
import com.capg.chat.model.Chat;

@Service("chatService")
public class ChatServiceImpl implements IChatService{

	@Autowired
	private IChatDao chatDao;

	@Override
	public List<Chat> saveChat(Chat chat) {
		chatDao.save(chat);
		
		return chatDao.findAll();
	}

	@Override
	public List<Chat> getAllChats() {
		return chatDao.findAll();
	}
}
