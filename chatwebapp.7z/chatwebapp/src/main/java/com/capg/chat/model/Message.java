package com.capg.chat.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties()
public class Message {

	@Id
	@GeneratedValue
	private Integer message_Id;
	private String text;
	private LocalDate date=LocalDate.now();
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.PERSIST)
	@JoinTable(name="chat_message",
	joinColumns= {@JoinColumn(name="message_Id")},
	inverseJoinColumns={@JoinColumn(name="chat_Id")})
	@JsonIgnoreProperties("messages")
	private List<Chat> chats;
	
	
	public Message() {
		super();
	}
	public Message(Integer message_Id, String text, LocalDate date) {
		super();
		this.message_Id = message_Id;
		this.text = text;
		this.date = date;
	}
	
	public List<Chat> getChats() {
		return chats;
	}
	public void setChats(List<Chat> chats) {
		this.chats = chats;
	}
	public Integer getMessage_Id() {
		return message_Id;
	}
	public void setMessage_Id(Integer message_Id) {
		this.message_Id = message_Id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Message [message_Id=" + message_Id + ", text=" + text + ", date=" + date + ", chats=" + chats + "]";
	}
	
	
	
}
